# Push nach GitHub

## Neues Remote anlegen

1. Neues leeres Repository auf GitHub erzeugen.
2. Dann lokal im Exportordner:

```powershell
git remote add origin <DEIN-REPO-URL>
git branch -M main
git push -u origin main
git tag v1
git push origin v1
```

## Optional

- Vor dem Push den Startpfad lokal pruefen:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\start-local-sim.ps1
```
